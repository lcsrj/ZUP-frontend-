// Hook central para listar ocorrências do backend Node.
// Mantém o mesmo shape de `Report` usado hoje pelo front para não quebrar UIs.

import { useQuery } from "@tanstack/react-query";
import {
  listOccurrences,
  mapOccurrenceToReport,
  type ListOccurrencesQuery,
} from "@/lib/occurrences-api";
import type { Report } from "@/data/mockData";

export function useOccurrences(query: ListOccurrencesQuery = {}) {
  const q = useQuery({
    queryKey: ["occurrences", query],
    queryFn: async () => {
      const raw = await listOccurrences(query);
      return raw.map(mapOccurrenceToReport);
    },
    staleTime: 30_000,
    retry: 1,
  });

  return {
    reports: (q.data ?? []) as Report[],
    isLoading: q.isLoading,
    isError: q.isError,
    error: q.error,
    refetch: q.refetch,
  };
}
