/// <reference types="google.maps" />
import { useEffect, useState } from "react";


const BROWSER_KEY = import.meta.env.VITE_LOVABLE_CONNECTOR_GOOGLE_MAPS_BROWSER_KEY as string | undefined;
const CHANNEL = import.meta.env.VITE_LOVABLE_CONNECTOR_GOOGLE_MAPS_TRACKING_ID as string | undefined;
const CALLBACK_NAME = "__zupGoogleMapsInit";

let loaderPromise: Promise<typeof google> | null = null;

export function loadGoogleMaps(): Promise<typeof google> {
  if (typeof window === "undefined") {
    return Promise.reject(new Error("Google Maps só pode ser carregado no navegador"));
  }
  if ((window as any).google?.maps) {
    return Promise.resolve((window as any).google);
  }
  if (loaderPromise) return loaderPromise;

  if (!BROWSER_KEY) {
    return Promise.reject(
      new Error(
        "Google Maps Browser Key ausente. Conecte a integração Google Maps Platform nas configurações."
      )
    );
  }

  loaderPromise = new Promise((resolve, reject) => {
    (window as any)[CALLBACK_NAME] = () => {
      resolve((window as any).google);
    };
    const script = document.createElement("script");
    const params = new URLSearchParams({
      key: BROWSER_KEY,
      libraries: "places",
      loading: "async",
      callback: CALLBACK_NAME,
      v: "weekly",
    });
    if (CHANNEL) params.set("channel", CHANNEL);
    script.src = `https://maps.googleapis.com/maps/api/js?${params.toString()}`;
    script.async = true;
    script.defer = true;
    script.onerror = () => {
      loaderPromise = null;
      reject(new Error("Falha ao carregar Google Maps JavaScript API"));
    };
    document.head.appendChild(script);
  });
  return loaderPromise;
}

export interface UseGoogleMapsState {
  ready: boolean;
  error: string | null;
  google: typeof google | null;
}

export function useGoogleMaps(): UseGoogleMapsState {
  const [state, setState] = useState<UseGoogleMapsState>(() => ({
    ready: typeof window !== "undefined" && !!(window as any).google?.maps,
    error: null,
    google: typeof window !== "undefined" ? ((window as any).google ?? null) : null,
  }));

  useEffect(() => {
    let cancelled = false;
    if (state.ready) return;
    loadGoogleMaps()
      .then((g) => {
        if (!cancelled) setState({ ready: true, error: null, google: g });
      })
      .catch((err: Error) => {
        if (!cancelled) setState({ ready: false, error: err.message, google: null });
      });
    return () => {
      cancelled = true;
    };
  }, [state.ready]);

  return state;
}
