/// <reference types="google.maps" />
import { useEffect, useRef, useState, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { useGoogleMaps } from "@/hooks/useGoogleMaps";
import { currentMunicipality } from "@/data/mockData";
import { MapPin, Loader2 } from "lucide-react";

interface AddressSelection {
  description: string;
  placeId: string;
  location?: { lat: number; lng: number };
}

interface AddressAutocompleteProps {
  value: string;
  onChange: (text: string) => void;
  onSelect: (selection: AddressSelection) => void;
  placeholder?: string;
  biasCenter?: [number, number];
  biasRadiusMeters?: number;
  id?: string;
  "aria-describedby"?: string;
}

// Modern Places API (New) — AutocompleteSuggestion. No legacy Autocomplete widget.
const AddressAutocomplete = ({
  value,
  onChange,
  onSelect,
  placeholder = "Buscar endereço em Videira/SC...",
  biasCenter = currentMunicipality.center,
  biasRadiusMeters = 15000,
  id,
  ...rest
}: AddressAutocompleteProps) => {
  const { ready, error } = useGoogleMaps();
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const sessionTokenRef = useRef<any>(null);
  const debounceRef = useRef<number | null>(null);
  const placesLibRef = useRef<any>(null);

  const ensureSession = useCallback(async () => {
    if (!ready) return;
    if (!placesLibRef.current) {
      placesLibRef.current = await google.maps.importLibrary("places");
    }
    if (!sessionTokenRef.current) {
      sessionTokenRef.current = new placesLibRef.current.AutocompleteSessionToken();
    }
    return placesLibRef.current;
  }, [ready]);

  const fetchSuggestions = useCallback(
    async (input: string) => {
      const lib = await ensureSession();
      if (!lib) return;
      try {
        const { suggestions: result } = await lib.AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input,
          sessionToken: sessionTokenRef.current,
          includedRegionCodes: ["br"],
          locationBias: {
            circle: {
              center: { lat: biasCenter[0], lng: biasCenter[1] },
              radius: biasRadiusMeters,
            },
          },
        });
        setSuggestions(result ?? []);
        setOpen(true);
        setActiveIndex(-1);
      } catch (err) {
        console.error("Autocomplete error:", err);
        setSuggestions([]);
      } finally {
        setLoading(false);
      }
    },
    [biasCenter, biasRadiusMeters, ensureSession]
  );

  useEffect(() => {
    if (!ready) return;
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    const trimmed = value.trim();
    if (trimmed.length < 3) {
      setSuggestions([]);
      setOpen(false);
      setLoading(false);
      return;
    }
    setLoading(true);
    debounceRef.current = window.setTimeout(() => {
      fetchSuggestions(trimmed);
    }, 250);
    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, [value, ready, fetchSuggestions]);

  const handlePick = async (index: number) => {
    const suggestion = suggestions[index];
    if (!suggestion?.placePrediction) return;
    const prediction = suggestion.placePrediction;
    const description = prediction.text?.toString() ?? "";
    onChange(description);
    setOpen(false);
    setSuggestions([]);
    try {
      const place = prediction.toPlace();
      await place.fetchFields({ fields: ["location", "formattedAddress"] });
      const loc = place.location
        ? { lat: place.location.lat(), lng: place.location.lng() }
        : undefined;
      onSelect({
        description: place.formattedAddress ?? description,
        placeId: prediction.placeId,
        location: loc,
      });
    } catch (err) {
      console.error("Place details error:", err);
      onSelect({ description, placeId: prediction.placeId });
    } finally {
      // Renew session after a selection
      sessionTokenRef.current = placesLibRef.current
        ? new placesLibRef.current.AutocompleteSessionToken()
        : null;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!open || suggestions.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, suggestions.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter" && activeIndex >= 0) {
      e.preventDefault();
      handlePick(activeIndex);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  };

  return (
    <div className="relative">
      <div className="relative">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
        <Input
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => suggestions.length > 0 && setOpen(true)}
          onBlur={() => window.setTimeout(() => setOpen(false), 120)}
          onKeyDown={handleKeyDown}
          placeholder={ready ? placeholder : error ? "Busca de endereço indisponível" : "Carregando..."}
          disabled={!ready}
          className="pl-9"
          role="combobox"
          aria-expanded={open}
          aria-autocomplete="list"
          aria-controls="address-suggestions"
          {...rest}
        />
        {loading && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground animate-spin" />
        )}
      </div>
      {open && suggestions.length > 0 && (
        <ul
          id="address-suggestions"
          role="listbox"
          className="absolute z-[2200] mt-1 w-full bg-popover border border-border rounded-md shadow-lg max-h-64 overflow-y-auto"
        >
          {suggestions.map((s, i) => {
            const pred = s.placePrediction;
            if (!pred) return null;
            const main = pred.mainText?.toString() ?? pred.text?.toString();
            const secondary = pred.secondaryText?.toString();
            return (
              <li
                key={pred.placeId ?? i}
                role="option"
                aria-selected={activeIndex === i}
                onMouseDown={(e) => {
                  e.preventDefault();
                  handlePick(i);
                }}
                onMouseEnter={() => setActiveIndex(i)}
                className={`px-3 py-2 text-sm cursor-pointer ${
                  activeIndex === i ? "bg-accent text-accent-foreground" : "hover:bg-accent/50"
                }`}
              >
                <div className="font-medium text-foreground">{main}</div>
                {secondary && <div className="text-xs text-muted-foreground">{secondary}</div>}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
};

export default AddressAutocomplete;
