/// <reference types="google.maps" />
import { useEffect, useRef } from "react";
import { useGoogleMaps } from "@/hooks/useGoogleMaps";
import { type Report, getStatusColor, currentMunicipality, neighborhoods } from "@/data/mockData";
import { AlertCircle } from "lucide-react";

interface MapViewProps {
  reports: Report[];
  center?: [number, number];
  zoom?: number;
  onReportClick?: (report: Report) => void;
  className?: string;
  onMapClick?: (lat: number, lng: number) => void;
  selectedPosition?: [number, number] | null;
  showNeighborhoodBoundaries?: boolean;
}

const NEIGHBORHOOD_CENTERS: Record<string, [number, number]> = {
  Centro: [-27.0070, -51.1518],
  Alvorada: [-27.0095, -51.1545],
  Matriz: [-27.0073, -51.1532],
  Farroupilha: [-27.0040, -51.1485],
  "Santo Antônio": [-27.0112, -51.1562],
  "São Cristóvão": [-27.0052, -51.1462],
  "Bom Retiro": [-27.0102, -51.1500],
  "San Remo": [-27.0048, -51.1572],
  "Presidente Médici": [-27.0020, -51.1505],
  Maro: [-27.0135, -51.1485],
  "Rio das Pedras": [-27.0140, -51.1530],
  Industrial: [-27.0122, -51.1432],
  "Grápia": [-26.9990, -51.1545],
  Panorama: [-27.0030, -51.1552],
  "N. S. das Graças": [-27.0080, -51.1590],
};

const hexAround = ([lat, lng]: [number, number], radiusDeg = 0.0018) => {
  const points: { lat: number; lng: number }[] = [];
  for (let i = 0; i < 6; i++) {
    const a = (Math.PI / 3) * i + Math.PI / 6;
    points.push({ lat: lat + radiusDeg * Math.sin(a), lng: lng + radiusDeg * Math.cos(a) });
  }
  return points;
};

const pinSvg = (color: string) =>
  `data:image/svg+xml;utf-8,${encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="40" viewBox="0 0 32 40">
      <path d="M16 0C7.2 0 0 7.2 0 16c0 11 16 24 16 24s16-13 16-24C32 7.2 24.8 0 16 0z" fill="${color}" stroke="white" stroke-width="2"/>
      <circle cx="16" cy="16" r="5" fill="white"/>
    </svg>`
  )}`;

const MapView = ({
  reports,
  center = currentMunicipality.center,
  zoom = currentMunicipality.zoom,
  onReportClick,
  className = "",
  onMapClick,
  selectedPosition,
  showNeighborhoodBoundaries = true,
}: MapViewProps) => {
  const { ready, error } = useGoogleMaps();
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const selectedMarkerRef = useRef<google.maps.Marker | null>(null);
  const polygonsRef = useRef<google.maps.Polygon[]>([]);
  const labelsRef = useRef<google.maps.InfoWindow[]>([]);
  const clickListenerRef = useRef<google.maps.MapsEventListener | null>(null);
  const infoRef = useRef<google.maps.InfoWindow | null>(null);

  // Init map
  useEffect(() => {
    if (!ready || !containerRef.current || mapRef.current) return;
    mapRef.current = new google.maps.Map(containerRef.current, {
      center: { lat: center[0], lng: center[1] },
      zoom,
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: false,
      clickableIcons: false,
    });
    infoRef.current = new google.maps.InfoWindow({ disableAutoPan: true });
  }, [ready]);

  // Map click handler
  useEffect(() => {
    if (!mapRef.current) return;
    clickListenerRef.current?.remove();
    if (onMapClick) {
      clickListenerRef.current = mapRef.current.addListener("click", (e: google.maps.MapMouseEvent) => {
        if (e.latLng) onMapClick(e.latLng.lat(), e.latLng.lng());
      });
    }
    return () => clickListenerRef.current?.remove();
  }, [onMapClick, ready]);

  // Recenter when prop changes
  useEffect(() => {
    if (!mapRef.current) return;
    mapRef.current.setCenter({ lat: center[0], lng: center[1] });
  }, [center[0], center[1]]);

  // Neighborhood boundaries
  useEffect(() => {
    if (!mapRef.current) return;
    polygonsRef.current.forEach((p) => p.setMap(null));
    labelsRef.current.forEach((l) => l.close());
    polygonsRef.current = [];
    labelsRef.current = [];
    if (!showNeighborhoodBoundaries) return;

    neighborhoods.forEach((n) => {
      const c = NEIGHBORHOOD_CENTERS[n.name];
      if (!c) return;
      const poly = new google.maps.Polygon({
        paths: hexAround(c),
        strokeColor: "hsl(262, 60%, 45%)",
        strokeOpacity: 0.85,
        strokeWeight: 2,
        fillColor: "hsl(262, 60%, 45%)",
        fillOpacity: 0.04,
        clickable: false,
        map: mapRef.current!,
      });
      polygonsRef.current.push(poly);

      const label = new google.maps.InfoWindow({
        content: `<div style="font-size:10px;font-weight:600;color:hsl(262,60%,35%);padding:1px 4px;">${n.name}</div>`,
        position: { lat: c[0], lng: c[1] },
        disableAutoPan: true,
      });
      label.open({ map: mapRef.current! });
      labelsRef.current.push(label);
    });
  }, [ready, showNeighborhoodBoundaries]);

  // Report markers
  useEffect(() => {
    if (!mapRef.current) return;
    markersRef.current.forEach((m) => m.setMap(null));
    markersRef.current = [];

    reports.forEach((report) => {
      const marker = new google.maps.Marker({
        position: { lat: report.lat, lng: report.lng },
        map: mapRef.current!,
        icon: {
          url: pinSvg(getStatusColor(report.status)),
          scaledSize: new google.maps.Size(32, 40),
          anchor: new google.maps.Point(16, 40),
        },
        title: report.title,
      });
      marker.addListener("mouseover", () => {
        if (!infoRef.current) return;
        infoRef.current.setContent(
          `<div style="font-size:12px;"><strong>${report.title}</strong><br/><span style="font-size:11px;color:#666">${report.neighborhood}</span></div>`
        );
        infoRef.current.open({ anchor: marker, map: mapRef.current! });
      });
      marker.addListener("mouseout", () => infoRef.current?.close());
      if (onReportClick) {
        marker.addListener("click", () => onReportClick(report));
      }
      markersRef.current.push(marker);
    });
  }, [ready, reports, onReportClick]);

  // Selected position marker
  useEffect(() => {
    if (!mapRef.current) return;
    selectedMarkerRef.current?.setMap(null);
    selectedMarkerRef.current = null;
    if (!selectedPosition) return;
    selectedMarkerRef.current = new google.maps.Marker({
      position: { lat: selectedPosition[0], lng: selectedPosition[1] },
      map: mapRef.current,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 9,
        fillColor: "hsl(262,60%,45%)",
        fillOpacity: 1,
        strokeColor: "#fff",
        strokeWeight: 3,
      },
      zIndex: 999,
    });
    mapRef.current.panTo({ lat: selectedPosition[0], lng: selectedPosition[1] });
  }, [selectedPosition?.[0], selectedPosition?.[1]]);

  return (
    <div className={`w-full h-full min-h-[400px] rounded-lg overflow-hidden bg-muted ${className}`}>
      {error ? (
        <div className="w-full h-full min-h-[400px] flex flex-col items-center justify-center p-6 text-center text-sm text-muted-foreground gap-2">
          <AlertCircle className="w-6 h-6 text-destructive" />
          <p className="font-medium text-foreground">Mapa indisponível</p>
          <p className="text-xs max-w-xs">{error}</p>
        </div>
      ) : (
        <div ref={containerRef} className="w-full h-full min-h-[400px]" />
      )}
    </div>
  );
};

export default MapView;
