export type ReportStatus = 'pre_publicacao' | 'aguardando_validacao' | 'em_analise' | 'em_execucao' | 'resolvido' | 'resolucao_validada' | 'resolucao_rejeitada' | 'arquivado';
export type OrganType = 'prefeitura' | 'agua_saneamento' | 'energia_luz';
export type Priority = 'baixa' | 'media' | 'alta' | 'critica';

export interface Municipality {
  id: string;
  name: string;
  state: string;
  center: [number, number];
  zoom: number;
}

export interface Neighborhood {
  id: string;
  name: string;
  municipalityId: string;
}

export interface Category {
  id: string;
  name: string;
  organ: OrganType;
  subcategories: Subcategory[];
}

export interface Subcategory {
  id: string;
  name: string;
  categoryId: string;
}

export interface Report {
  id: string;
  title: string;
  description: string;
  categoryId: string;
  subcategoryId: string;
  status: ReportStatus;
  priority: Priority;
  lat: number;
  lng: number;
  neighborhood: string;
  municipalityId: string;
  createdAt: string;
  updatedAt: string;
  validations: number;
  requiredValidations: number;
  resolutionValidations: number;
  organ: OrganType;
  imageUrl: string;
  imageUrls?: string[];
  estimatedCompletion?: string;
  statusHistory: StatusHistoryEntry[];
  rejectionReason?: string;
  isRecurrence?: boolean;
  previousReportId?: string;
  recurrenceCount?: number;
}

export interface StatusHistoryEntry {
  status: ReportStatus;
  date: string;
  note?: string;
  by?: string;
  reason?: string;
}

export interface ValidationRequest {
  id: string;
  reportId: string;
  reportTitle: string;
  reportImageUrl: string;
  type: 'existence' | 'resolution';
  deadline: string;
  neighborhood: string;
  lat: number;
  lng: number;
}

export const DUPLICATE_RADIUS_METERS = 7;
export const NEARBY_RADIUS_METERS = 500;

export const rejectionReasons = [
  { id: 'duplicada', label: 'Ocorrência duplicada' },
  { id: 'localizacao_incorreta', label: 'Localização incorreta' },
  { id: 'imagem_insuficiente', label: 'Imagem insuficiente' },
  { id: 'categoria_incorreta', label: 'Categoria incorreta' },
  { id: 'nao_confirmada', label: 'Não foi possível confirmar existência' },
  { id: 'ja_resolvido', label: 'Problema já resolvido' },
  { id: 'conteudo_inadequado', label: 'Conteúdo inadequado' },
];

export const priorityLabels: Record<Priority, string> = {
  baixa: 'Baixa',
  media: 'Média',
  alta: 'Alta',
  critica: 'Crítica',
};

export const priorityColors: Record<Priority, string> = {
  baixa: 'hsl(210, 14%, 70%)',
  media: 'hsl(45, 100%, 51%)',
  alta: 'hsl(25, 95%, 53%)',
  critica: 'hsl(0, 84%, 60%)',
};

export const currentMunicipality: Municipality = {
  id: 'videira-sc',
  name: 'Videira',
  state: 'SC',
  center: [-27.0078, -51.1519],
  zoom: 14,
};

export const neighborhoods: Neighborhood[] = [
  { id: 'centro', name: 'Centro', municipalityId: 'videira-sc' },
  { id: 'alvorada', name: 'Alvorada', municipalityId: 'videira-sc' },
  { id: 'matriz', name: 'Matriz', municipalityId: 'videira-sc' },
  { id: 'farroupilha', name: 'Farroupilha', municipalityId: 'videira-sc' },
  { id: 'santo-antonio', name: 'Santo Antônio', municipalityId: 'videira-sc' },
  { id: 'sao-cristovao', name: 'São Cristóvão', municipalityId: 'videira-sc' },
  { id: 'bom-retiro', name: 'Bom Retiro', municipalityId: 'videira-sc' },
  { id: 'san-remo', name: 'San Remo', municipalityId: 'videira-sc' },
  { id: 'presidente-medici', name: 'Presidente Médici', municipalityId: 'videira-sc' },
  { id: 'maro', name: 'Maro', municipalityId: 'videira-sc' },
  { id: 'rio-das-pedras', name: 'Rio das Pedras', municipalityId: 'videira-sc' },
  { id: 'industrial', name: 'Industrial', municipalityId: 'videira-sc' },
  { id: 'grapia', name: 'Grápia', municipalityId: 'videira-sc' },
  { id: 'panorama', name: 'Panorama', municipalityId: 'videira-sc' },
  { id: 'nossa-senhora-das-gracas', name: 'N. S. das Graças', municipalityId: 'videira-sc' },
];

export const neighborhoodNames = neighborhoods.map(n => n.name);

export const categories: Category[] = [
  {
    id: 'infra', name: 'Infraestrutura Urbana', organ: 'prefeitura',
    subcategories: [
      { id: 'buraco', name: 'Buraco', categoryId: 'infra' },
      { id: 'grade_quebrada', name: 'Grade Quebrada', categoryId: 'infra' },
      { id: 'lixeira_destruida', name: 'Lixeira Destruída', categoryId: 'infra' },
      { id: 'lixeira_entupida', name: 'Lixeira Entupida', categoryId: 'infra' },
      { id: 'bueiro_entupido', name: 'Bueiro Entupido', categoryId: 'infra' },
    ],
  },
  {
    id: 'estrutural', name: 'Problemas Estruturais', organ: 'prefeitura',
    subcategories: [
      { id: 'erosao', name: 'Erosão', categoryId: 'estrutural' },
      { id: 'dano_estrutural', name: 'Dano Estrutural Grave', categoryId: 'estrutural' },
      { id: 'longa_execucao', name: 'Problema de Longa Execução', categoryId: 'estrutural' },
    ],
  },
  {
    id: 'iluminacao', name: 'Iluminação Pública', organ: 'prefeitura',
    subcategories: [
      { id: 'poste_apagado', name: 'Poste Apagado', categoryId: 'iluminacao' },
      { id: 'poste_piscando', name: 'Poste Piscando', categoryId: 'iluminacao' },
      { id: 'falha_iluminacao', name: 'Falha de Iluminação', categoryId: 'iluminacao' },
    ],
  },
  {
    id: 'servico', name: 'Serviço Público', organ: 'prefeitura',
    subcategories: [
      { id: 'falha_manutencao', name: 'Falha de Manutenção', categoryId: 'servico' },
      { id: 'coleta_irregular', name: 'Coleta Irregular', categoryId: 'servico' },
      { id: 'problema_operacional', name: 'Problema Operacional', categoryId: 'servico' },
    ],
  },
  {
    id: 'agua', name: 'Água e Saneamento (VISAN)', organ: 'agua_saneamento',
    subcategories: [
      { id: 'vazamento', name: 'Vazamento', categoryId: 'agua' },
      { id: 'falta_agua', name: 'Falta de Água', categoryId: 'agua' },
      { id: 'esgoto', name: 'Esgoto', categoryId: 'agua' },
      { id: 'tampa_quebrada', name: 'Tampa Quebrada', categoryId: 'agua' },
    ],
  },
  {
    id: 'energia', name: 'Energia e Iluminação (CELESC)', organ: 'energia_luz',
    subcategories: [
      { id: 'falta_energia', name: 'Falta de Energia Pontual', categoryId: 'energia' },
      { id: 'poste_risco', name: 'Poste com Risco', categoryId: 'energia' },
      { id: 'fiacao_exposta', name: 'Fiação Exposta', categoryId: 'energia' },
      { id: 'problema_eletrico', name: 'Problema Elétrico Visível', categoryId: 'energia' },
    ],
  },
  {
    id: 'vandalismo', name: 'Vandalismo', organ: 'prefeitura',
    subcategories: [
      { id: 'pichacao', name: 'Pichação', categoryId: 'vandalismo' },
      { id: 'descarte_irregular', name: 'Descarte Irregular de Lixo', categoryId: 'vandalismo' },
      { id: 'destruicao_patrimonio', name: 'Destruição de Patrimônio Público', categoryId: 'vandalismo' },
    ],
  },
];

export const mockReports: Report[] = [
  {
    id: '1', title: 'Buraco na Rua Dona Francisca',
    description: 'Buraco grande na via principal, oferecendo risco a veículos e pedestres. Aproximadamente 1 metro de diâmetro.',
    categoryId: 'infra', subcategoryId: 'buraco', status: 'em_analise', priority: 'alta',
    lat: -27.0065, lng: -51.1510, neighborhood: 'Centro', municipalityId: 'videira-sc',
    createdAt: '2026-03-15T10:30:00', updatedAt: '2026-03-15T10:30:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-15T10:30:00', note: 'Ocorrência registrada pela comunidade' },
      { status: 'em_analise', date: '2026-03-16T08:00:00', note: 'Validação comunitária concluída — 2 confirmações' },
    ],
  },
  {
    id: '2', title: 'Vazamento na Rua Benjamin Constant',
    description: 'Vazamento de água limpa na calçada há 3 dias. Grande desperdício de água potável.',
    categoryId: 'agua', subcategoryId: 'vazamento', status: 'em_execucao', priority: 'alta',
    lat: -27.0090, lng: -51.1545, neighborhood: 'Alvorada', municipalityId: 'videira-sc',
    createdAt: '2026-03-10T14:00:00', updatedAt: '2026-03-18T09:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'agua_saneamento', imageUrl: 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?w=400',
    estimatedCompletion: '2026-03-25',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-10T14:00:00', note: 'Ocorrência registrada pela comunidade' },
      { status: 'em_analise', date: '2026-03-11T10:00:00', note: 'Validação comunitária concluída' },
      { status: 'em_execucao', date: '2026-03-18T09:00:00', note: 'Equipe técnica encaminhada ao local', by: 'Cia de Água e Saneamento' },
    ],
  },
  {
    id: '3', title: 'Poste apagado na Farroupilha',
    description: 'Poste completamente apagado há uma semana. Trecho escuro e perigoso à noite.',
    categoryId: 'iluminacao', subcategoryId: 'poste_apagado', status: 'resolvido', priority: 'media',
    lat: -27.0035, lng: -51.1480, neighborhood: 'Farroupilha', municipalityId: 'videira-sc',
    createdAt: '2026-03-01T18:00:00', updatedAt: '2026-03-20T16:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 1,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-01T18:00:00', note: 'Ocorrência registrada pela comunidade' },
      { status: 'em_analise', date: '2026-03-02T10:00:00', note: 'Validação comunitária concluída' },
      { status: 'em_execucao', date: '2026-03-12T10:00:00', note: 'Manutenção agendada', by: 'Prefeitura Municipal' },
      { status: 'resolvido', date: '2026-03-20T16:00:00', note: 'Lâmpada substituída com sucesso', by: 'Prefeitura Municipal' },
    ],
  },
  {
    id: '4', title: 'Fiação exposta no Santo Antônio',
    description: 'Fios elétricos expostos próximo à escola municipal. Risco de choque elétrico para crianças.',
    categoryId: 'energia', subcategoryId: 'fiacao_exposta', status: 'aguardando_validacao', priority: 'critica',
    lat: -27.0110, lng: -51.1560, neighborhood: 'Santo Antônio', municipalityId: 'videira-sc',
    createdAt: '2026-03-25T08:00:00', updatedAt: '2026-03-25T08:00:00',
    validations: 4, requiredValidations: 6, resolutionValidations: 0,
    organ: 'energia_luz', imageUrl: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400',
    statusHistory: [{ status: 'aguardando_validacao', date: '2026-03-25T08:00:00', note: 'Ocorrência registrada — aguardando validação comunitária' }],
  },
  {
    id: '5', title: 'Bueiro entupido no São Cristóvão',
    description: 'Bueiro completamente entupido causando alagamento em dias de chuva forte.',
    categoryId: 'infra', subcategoryId: 'bueiro_entupido', status: 'resolucao_validada', priority: 'media',
    lat: -27.0050, lng: -51.1460, neighborhood: 'São Cristóvão', municipalityId: 'videira-sc',
    createdAt: '2026-02-20T11:00:00', updatedAt: '2026-03-15T14:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 3,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-02-20T11:00:00', note: 'Ocorrência registrada pela comunidade' },
      { status: 'em_analise', date: '2026-02-21T08:00:00', note: 'Validação comunitária concluída' },
      { status: 'em_execucao', date: '2026-03-01T09:00:00', note: 'Equipe de manutenção acionada', by: 'Prefeitura Municipal' },
      { status: 'resolvido', date: '2026-03-10T15:00:00', note: 'Bueiro desobstruído', by: 'Prefeitura Municipal' },
      { status: 'resolucao_validada', date: '2026-03-15T14:00:00', note: 'Resolução confirmada pela comunidade' },
    ],
  },
  {
    id: '6', title: 'Esgoto a céu aberto no Bom Retiro',
    description: 'Esgoto escorrendo pela rua há mais de um mês. Situação insalubre e mau cheiro intenso.',
    categoryId: 'agua', subcategoryId: 'esgoto', status: 'em_analise', priority: 'critica',
    lat: -27.0100, lng: -51.1500, neighborhood: 'Bom Retiro', municipalityId: 'videira-sc',
    createdAt: '2026-02-28T16:00:00', updatedAt: '2026-02-28T16:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'agua_saneamento', imageUrl: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-02-28T16:00:00', note: 'Ocorrência registrada pela comunidade' },
      { status: 'em_analise', date: '2026-03-01T09:00:00', note: 'Validação comunitária concluída' },
    ],
    recurrenceCount: 2, isRecurrence: true,
  },
  {
    id: '7', title: 'Grade de proteção quebrada na Matriz',
    description: 'Grade de proteção da ponte sobre o rio está quebrada, oferecendo risco a pedestres.',
    categoryId: 'infra', subcategoryId: 'grade_quebrada', status: 'em_execucao', priority: 'alta',
    lat: -27.0072, lng: -51.1530, neighborhood: 'Matriz', municipalityId: 'videira-sc',
    createdAt: '2026-03-05T09:30:00', updatedAt: '2026-03-22T11:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400',
    estimatedCompletion: '2026-04-05',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-05T09:30:00', note: 'Ocorrência registrada pela comunidade' },
      { status: 'em_analise', date: '2026-03-06T08:00:00', note: 'Validação comunitária concluída' },
      { status: 'em_execucao', date: '2026-03-22T11:00:00', note: 'Material adquirido, reparo em andamento', by: 'Prefeitura Municipal' },
    ],
  },
  {
    id: '8', title: 'Falta de energia recorrente no San Remo',
    description: 'Quedas de energia frequentes, especialmente nos horários de pico da noite.',
    categoryId: 'energia', subcategoryId: 'falta_energia', status: 'resolucao_rejeitada', priority: 'alta',
    lat: -27.0045, lng: -51.1575, neighborhood: 'San Remo', municipalityId: 'videira-sc',
    createdAt: '2026-03-08T20:00:00', updatedAt: '2026-03-28T10:00:00',
    validations: 6, requiredValidations: 6, resolutionValidations: 0,
    organ: 'energia_luz', imageUrl: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=400',
    rejectionReason: 'Problema persiste após intervenção',
    isRecurrence: true, recurrenceCount: 3,
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-08T20:00:00', note: 'Ocorrência registrada pela comunidade' },
      { status: 'em_analise', date: '2026-03-09T10:00:00', note: 'Validação comunitária concluída' },
      { status: 'em_execucao', date: '2026-03-15T08:00:00', note: 'Inspeção na rede elétrica', by: 'Cia de Energia' },
      { status: 'resolvido', date: '2026-03-25T14:00:00', note: 'Transformador substituído', by: 'Cia de Energia' },
      { status: 'resolucao_rejeitada', date: '2026-03-28T10:00:00', note: 'Comunidade reportou que o problema persiste', reason: 'Problema persiste após intervenção' },
    ],
  },
  {
    id: '9', title: 'Coleta irregular no Industrial',
    description: 'Lixo acumulado há 5 dias sem coleta na região do distrito industrial.',
    categoryId: 'servico', subcategoryId: 'coleta_irregular', status: 'em_execucao', priority: 'media',
    lat: -27.0120, lng: -51.1430, neighborhood: 'Industrial', municipalityId: 'videira-sc',
    createdAt: '2026-03-28T07:00:00', updatedAt: '2026-04-15T11:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400',
    estimatedCompletion: '2026-04-22',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-28T07:00:00', note: 'Ocorrência registrada' },
      { status: 'em_analise', date: '2026-03-30T10:00:00' },
      { status: 'em_execucao', date: '2026-04-15T11:00:00', by: 'Prefeitura Municipal' },
    ],
  },
  {
    id: '10', title: 'Erosão na margem do rio no Panorama',
    description: 'Erosão avançada comprometendo calçada e com risco de desabamento.',
    categoryId: 'estrutural', subcategoryId: 'erosao', status: 'em_execucao', priority: 'critica',
    lat: -27.0030, lng: -51.1550, neighborhood: 'Panorama', municipalityId: 'videira-sc',
    createdAt: '2026-02-15T13:00:00', updatedAt: '2026-03-20T10:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400',
    estimatedCompletion: '2026-04-30',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-02-15T13:00:00', note: 'Ocorrência registrada pela comunidade' },
      { status: 'em_analise', date: '2026-02-16T08:00:00', note: 'Validação comunitária concluída' },
      { status: 'em_execucao', date: '2026-03-20T10:00:00', note: 'Obra de contenção iniciada no local', by: 'Prefeitura Municipal' },
    ],
  },
  // ===== Ocorrências adicionais espalhadas pelos bairros (evitando leito do Rio do Peixe) =====
  {
    id: '11', title: 'Pichação na fachada da escola municipal',
    description: 'Pichações recentes na parede lateral da escola, com palavras ofensivas visíveis da rua.',
    categoryId: 'vandalismo', subcategoryId: 'pichacao', status: 'resolvido', priority: 'media',
    lat: -27.0058, lng: -51.1438, neighborhood: 'São Cristóvão', municipalityId: 'videira-sc',
    createdAt: '2026-03-20T09:00:00', updatedAt: '2026-04-10T15:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 1,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1551845728-6820a30c64e1?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-20T09:00:00' },
      { status: 'em_analise', date: '2026-03-22T08:00:00' },
      { status: 'em_execucao', date: '2026-04-01T09:00:00', by: 'Prefeitura Municipal' },
      { status: 'resolvido', date: '2026-04-10T15:00:00', note: 'Parede repintada', by: 'Prefeitura Municipal' },
    ],
  },
  {
    id: '12', title: 'Descarte irregular de entulho',
    description: 'Caçamba clandestina depositada em terreno baldio, com restos de construção e móveis velhos.',
    categoryId: 'vandalismo', subcategoryId: 'descarte_irregular', status: 'em_analise', priority: 'alta',
    lat: -27.0155, lng: -51.1410, neighborhood: 'Industrial', municipalityId: 'videira-sc',
    createdAt: '2026-04-05T16:30:00', updatedAt: '2026-04-07T08:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-05T16:30:00' },
      { status: 'em_analise', date: '2026-04-07T08:00:00', note: 'Validação concluída' },
    ],
  },
  {
    id: '13', title: 'Banco de praça destruído',
    description: 'Banco de concreto da praça pública foi quebrado e tombado, com cacos espalhados.',
    categoryId: 'vandalismo', subcategoryId: 'destruicao_patrimonio', status: 'em_execucao', priority: 'media',
    lat: -27.0085, lng: -51.1472, neighborhood: 'Centro', municipalityId: 'videira-sc',
    createdAt: '2026-04-02T11:00:00', updatedAt: '2026-04-12T10:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400',
    estimatedCompletion: '2026-04-25',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-02T11:00:00' },
      { status: 'em_analise', date: '2026-04-04T08:00:00' },
      { status: 'em_execucao', date: '2026-04-12T10:00:00', note: 'Reparo agendado', by: 'Prefeitura Municipal' },
    ],
  },
  {
    id: '14', title: 'Lixeira pública entupida',
    description: 'Lixeira da praça transbordando há vários dias, atraindo insetos.',
    categoryId: 'infra', subcategoryId: 'lixeira_entupida', status: 'aguardando_validacao', priority: 'baixa',
    lat: -27.0095, lng: -51.1465, neighborhood: 'Centro', municipalityId: 'videira-sc',
    createdAt: '2026-04-14T07:30:00', updatedAt: '2026-04-14T07:30:00',
    validations: 0, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400',
    statusHistory: [{ status: 'aguardando_validacao', date: '2026-04-14T07:30:00' }],
  },
  {
    id: '15', title: 'Buraco profundo na Rua das Acácias',
    description: 'Buraco que já causou danos a pneus de moradores. Sinalizado provisoriamente.',
    categoryId: 'infra', subcategoryId: 'buraco', status: 'em_analise', priority: 'alta',
    lat: -27.0020, lng: -51.1495, neighborhood: 'Presidente Médici', municipalityId: 'videira-sc',
    createdAt: '2026-04-08T14:00:00', updatedAt: '2026-04-09T10:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-08T14:00:00' },
      { status: 'em_analise', date: '2026-04-09T10:00:00' },
    ],
  },
  {
    id: '16', title: 'Poste piscando intermitente',
    description: 'Poste que pisca durante toda a noite, causando desconforto aos moradores.',
    categoryId: 'iluminacao', subcategoryId: 'poste_piscando', status: 'aguardando_validacao', priority: 'baixa',
    lat: -26.9985, lng: -51.1535, neighborhood: 'Grápia', municipalityId: 'videira-sc',
    createdAt: '2026-04-13T22:00:00', updatedAt: '2026-04-13T22:00:00',
    validations: 1, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400',
    statusHistory: [{ status: 'aguardando_validacao', date: '2026-04-13T22:00:00' }],
  },
  {
    id: '17', title: 'Tampa de bueiro quebrada',
    description: 'Tampa de bueiro em pedaços, com risco de queda de pedestres e ciclistas.',
    categoryId: 'agua', subcategoryId: 'tampa_quebrada', status: 'em_execucao', priority: 'critica',
    lat: -27.0048, lng: -51.1450, neighborhood: 'São Cristóvão', municipalityId: 'videira-sc',
    createdAt: '2026-04-06T08:00:00', updatedAt: '2026-04-11T09:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'agua_saneamento', imageUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400',
    estimatedCompletion: '2026-04-22',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-06T08:00:00' },
      { status: 'em_analise', date: '2026-04-08T08:00:00' },
      { status: 'em_execucao', date: '2026-04-11T09:00:00', by: 'Cia de Água e Saneamento' },
    ],
  },
  {
    id: '18', title: 'Falta de água há 2 dias',
    description: 'Bairro inteiro sem abastecimento de água desde anteontem, sem aviso prévio.',
    categoryId: 'agua', subcategoryId: 'falta_agua', status: 'em_analise', priority: 'alta',
    lat: -27.0140, lng: -51.1495, neighborhood: 'Maro', municipalityId: 'videira-sc',
    createdAt: '2026-04-12T06:00:00', updatedAt: '2026-04-13T08:00:00',
    validations: 6, requiredValidations: 6, resolutionValidations: 0,
    organ: 'agua_saneamento', imageUrl: 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-12T06:00:00' },
      { status: 'em_analise', date: '2026-04-13T08:00:00' },
    ],
  },
  {
    id: '19', title: 'Poste com risco de queda',
    description: 'Poste de energia visivelmente inclinado após temporal. Risco grave para pedestres e veículos.',
    categoryId: 'energia', subcategoryId: 'poste_risco', status: 'em_execucao', priority: 'critica',
    lat: -27.0145, lng: -51.1535, neighborhood: 'Rio das Pedras', municipalityId: 'videira-sc',
    createdAt: '2026-04-04T17:00:00', updatedAt: '2026-04-09T08:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'energia_luz', imageUrl: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=400',
    estimatedCompletion: '2026-04-20',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-04T17:00:00' },
      { status: 'em_analise', date: '2026-04-05T10:00:00' },
      { status: 'em_execucao', date: '2026-04-09T08:00:00', by: 'Cia de Energia' },
    ],
  },
  {
    id: '20', title: 'Problema elétrico visível na rede',
    description: 'Faíscas saindo de transformador no topo do poste, especialmente em dias úmidos.',
    categoryId: 'energia', subcategoryId: 'problema_eletrico', status: 'em_execucao', priority: 'alta',
    lat: -27.0078, lng: -51.1595, neighborhood: 'N. S. das Graças', municipalityId: 'videira-sc',
    createdAt: '2026-03-28T19:30:00', updatedAt: '2026-04-12T10:00:00',
    validations: 6, requiredValidations: 6, resolutionValidations: 0,
    organ: 'energia_luz', imageUrl: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400',
    estimatedCompletion: '2026-04-23',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-28T19:30:00' },
      { status: 'em_analise', date: '2026-03-30T08:00:00' },
      { status: 'em_execucao', date: '2026-04-12T10:00:00', by: 'Cia de Energia' },
    ],
  },
  {
    id: '21', title: 'Falha de manutenção em praça',
    description: 'Brinquedos do parquinho enferrujados e quebrados, sem manutenção há meses.',
    categoryId: 'servico', subcategoryId: 'falha_manutencao', status: 'em_analise', priority: 'media',
    lat: -27.0095, lng: -51.1605, neighborhood: 'N. S. das Graças', municipalityId: 'videira-sc',
    createdAt: '2026-04-03T15:00:00', updatedAt: '2026-04-06T09:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-03T15:00:00' },
      { status: 'em_analise', date: '2026-04-06T09:00:00' },
    ],
  },
  {
    id: '22', title: 'Lixeira destruída por vandalismo',
    description: 'Lixeira pública arrancada e jogada na rua durante a madrugada.',
    categoryId: 'infra', subcategoryId: 'lixeira_destruida', status: 'em_execucao', priority: 'baixa',
    lat: -27.0050, lng: -51.1530, neighborhood: 'Alvorada', municipalityId: 'videira-sc',
    createdAt: '2026-03-30T06:00:00', updatedAt: '2026-04-12T09:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400',
    estimatedCompletion: '2026-04-22',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-30T06:00:00' },
      { status: 'em_analise', date: '2026-04-02T08:00:00' },
      { status: 'em_execucao', date: '2026-04-12T09:00:00', by: 'Prefeitura Municipal' },
    ],
  },
  {
    id: '23', title: 'Dano estrutural em muro de contenção',
    description: 'Muro de contenção apresenta rachaduras grandes e está se inclinando.',
    categoryId: 'estrutural', subcategoryId: 'dano_estrutural', status: 'em_analise', priority: 'critica',
    lat: -27.0010, lng: -51.1465, neighborhood: 'Presidente Médici', municipalityId: 'videira-sc',
    createdAt: '2026-04-01T10:00:00', updatedAt: '2026-04-05T11:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-01T10:00:00' },
      { status: 'em_analise', date: '2026-04-05T11:00:00' },
    ],
  },
  {
    id: '24', title: 'Pichação em monumento histórico',
    description: 'Monumento da praça central pichado com tinta spray durante o final de semana.',
    categoryId: 'vandalismo', subcategoryId: 'pichacao', status: 'em_analise', priority: 'alta',
    lat: -27.0068, lng: -51.1500, neighborhood: 'Matriz', municipalityId: 'videira-sc',
    createdAt: '2026-04-07T08:30:00', updatedAt: '2026-04-09T10:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1551845728-6820a30c64e1?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-07T08:30:00' },
      { status: 'em_analise', date: '2026-04-09T10:00:00' },
    ],
  },
  {
    id: '25', title: 'Poste apagado na entrada do bairro',
    description: 'Vários postes apagados na avenida principal, deixando trecho perigoso à noite.',
    categoryId: 'iluminacao', subcategoryId: 'poste_apagado', status: 'em_execucao', priority: 'media',
    lat: -27.0125, lng: -51.1455, neighborhood: 'Industrial', municipalityId: 'videira-sc',
    createdAt: '2026-04-02T20:00:00', updatedAt: '2026-04-10T09:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400',
    estimatedCompletion: '2026-04-19',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-02T20:00:00' },
      { status: 'em_analise', date: '2026-04-04T08:00:00' },
      { status: 'em_execucao', date: '2026-04-10T09:00:00', by: 'Prefeitura Municipal' },
    ],
  },
  {
    id: '26', title: 'Coleta atrasada no bairro',
    description: 'Caminhão de lixo não passou esta semana. Sacos acumulados nas calçadas.',
    categoryId: 'servico', subcategoryId: 'coleta_irregular', status: 'aguardando_validacao', priority: 'media',
    lat: -27.0088, lng: -51.1430, neighborhood: 'Bom Retiro', municipalityId: 'videira-sc',
    createdAt: '2026-04-15T08:00:00', updatedAt: '2026-04-15T08:00:00',
    validations: 1, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400',
    statusHistory: [{ status: 'aguardando_validacao', date: '2026-04-15T08:00:00' }],
  },
  {
    id: '27', title: 'Vazamento de água na esquina',
    description: 'Pequeno vazamento contínuo na junção da rede, formando poça permanente.',
    categoryId: 'agua', subcategoryId: 'vazamento', status: 'resolucao_validada', priority: 'media',
    lat: -27.0030, lng: -51.1605, neighborhood: 'Panorama', municipalityId: 'videira-sc',
    createdAt: '2026-03-15T11:00:00', updatedAt: '2026-04-08T14:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 2,
    organ: 'agua_saneamento', imageUrl: 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-15T11:00:00' },
      { status: 'em_analise', date: '2026-03-17T08:00:00' },
      { status: 'em_execucao', date: '2026-03-25T09:00:00', by: 'Cia de Água e Saneamento' },
      { status: 'resolvido', date: '2026-04-02T16:00:00', by: 'Cia de Água e Saneamento' },
      { status: 'resolucao_validada', date: '2026-04-08T14:00:00', note: 'Resolução confirmada pela comunidade' },
    ],
  },
  {
    id: '28', title: 'Buraco em rua de paralelepípedo',
    description: 'Pedras soltas e buraco profundo na rua histórica do bairro.',
    categoryId: 'infra', subcategoryId: 'buraco', status: 'em_analise', priority: 'media',
    lat: -27.0060, lng: -51.1595, neighborhood: 'N. S. das Graças', municipalityId: 'videira-sc',
    createdAt: '2026-04-09T13:00:00', updatedAt: '2026-04-11T10:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-09T13:00:00' },
      { status: 'em_analise', date: '2026-04-11T10:00:00' },
    ],
  },
  {
    id: '29', title: 'Destruição de parada de ônibus',
    description: 'Vidros e bancos da parada de ônibus quebrados durante a madrugada.',
    categoryId: 'vandalismo', subcategoryId: 'destruicao_patrimonio', status: 'em_analise', priority: 'alta',
    lat: -27.0150, lng: -51.1520, neighborhood: 'Rio das Pedras', municipalityId: 'videira-sc',
    createdAt: '2026-04-05T05:30:00', updatedAt: '2026-04-09T10:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-05T05:30:00' },
      { status: 'em_analise', date: '2026-04-09T10:00:00' },
    ],
  },
  {
    id: '30', title: 'Falha de iluminação em praça',
    description: 'Toda a iluminação da praça central do bairro está apagada há mais de duas semanas.',
    categoryId: 'iluminacao', subcategoryId: 'falha_iluminacao', status: 'em_execucao', priority: 'media',
    lat: -27.0105, lng: -51.1428, neighborhood: 'Industrial', municipalityId: 'videira-sc',
    createdAt: '2026-03-30T19:00:00', updatedAt: '2026-04-12T10:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400',
    estimatedCompletion: '2026-04-21',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-30T19:00:00' },
      { status: 'em_analise', date: '2026-04-02T08:00:00' },
      { status: 'em_execucao', date: '2026-04-12T10:00:00', by: 'Prefeitura Municipal' },
    ],
  },
  {
    id: '31', title: 'Esgoto vazando no asfalto',
    description: 'Água de esgoto aflorando no meio da rua, próximo a residências.',
    categoryId: 'agua', subcategoryId: 'esgoto', status: 'em_execucao', priority: 'alta',
    lat: -27.0118, lng: -51.1605, neighborhood: 'San Remo', municipalityId: 'videira-sc',
    createdAt: '2026-03-25T09:30:00', updatedAt: '2026-04-11T10:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'agua_saneamento', imageUrl: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=400',
    estimatedCompletion: '2026-04-25',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-03-25T09:30:00' },
      { status: 'em_analise', date: '2026-03-28T10:00:00' },
      { status: 'em_execucao', date: '2026-04-11T10:00:00', by: 'Cia de Água e Saneamento' },
    ],
  },
  {
    id: '32', title: 'Erosão em terreno público',
    description: 'Início de erosão em encosta após chuvas, ameaçando rua no nível superior.',
    categoryId: 'estrutural', subcategoryId: 'erosao', status: 'em_analise', priority: 'alta',
    lat: -26.9995, lng: -51.1515, neighborhood: 'Grápia', municipalityId: 'videira-sc',
    createdAt: '2026-04-08T15:00:00', updatedAt: '2026-04-12T09:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-08T15:00:00' },
      { status: 'em_analise', date: '2026-04-12T09:00:00' },
    ],
  },
  {
    id: '33', title: 'Descarte de móveis em via pública',
    description: 'Sofá, colchão e eletrodomésticos abandonados na calçada há vários dias.',
    categoryId: 'vandalismo', subcategoryId: 'descarte_irregular', status: 'em_execucao', priority: 'media',
    lat: -27.0102, lng: -51.1442, neighborhood: 'Bom Retiro', municipalityId: 'videira-sc',
    createdAt: '2026-04-05T10:00:00', updatedAt: '2026-04-13T08:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400',
    estimatedCompletion: '2026-04-20',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-05T10:00:00' },
      { status: 'em_analise', date: '2026-04-08T09:00:00' },
      { status: 'em_execucao', date: '2026-04-13T08:00:00', by: 'Prefeitura Municipal' },
    ],
  },
  {
    id: '34', title: 'Fiação solta em poste residencial',
    description: 'Cabos baixos e soltos passando sobre passeio público, ao alcance de pessoas.',
    categoryId: 'energia', subcategoryId: 'fiacao_exposta', status: 'em_analise', priority: 'alta',
    lat: -27.0028, lng: -51.1450, neighborhood: 'Farroupilha', municipalityId: 'videira-sc',
    createdAt: '2026-04-04T16:00:00', updatedAt: '2026-04-09T09:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'energia_luz', imageUrl: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-04T16:00:00' },
      { status: 'em_analise', date: '2026-04-09T09:00:00' },
    ],
  },
  {
    id: '35', title: 'Problema operacional em ponto de coleta',
    description: 'Contêineres do ecoponto cheios e sem rotação há semanas.',
    categoryId: 'servico', subcategoryId: 'problema_operacional', status: 'em_analise', priority: 'baixa',
    lat: -27.0140, lng: -51.1465, neighborhood: 'Maro', municipalityId: 'videira-sc',
    createdAt: '2026-04-06T09:00:00', updatedAt: '2026-04-10T11:00:00',
    validations: 2, requiredValidations: 2, resolutionValidations: 0,
    organ: 'prefeitura', imageUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400',
    statusHistory: [
      { status: 'aguardando_validacao', date: '2026-04-06T09:00:00' },
      { status: 'em_analise', date: '2026-04-10T11:00:00' },
    ],
  },
];

export const mockValidationRequests: ValidationRequest[] = [
  { id: 'v1', reportId: '9', reportTitle: 'Coleta irregular no Industrial', reportImageUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400', type: 'existence', deadline: '2026-04-04T07:00:00', neighborhood: 'Industrial', lat: -27.0120, lng: -51.1430 },
  { id: 'v2', reportId: '3', reportTitle: 'Poste apagado na Farroupilha', reportImageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400', type: 'resolution', deadline: '2026-04-03T16:00:00', neighborhood: 'Farroupilha', lat: -27.0035, lng: -51.1480 },
  { id: 'v3', reportId: '4', reportTitle: 'Fiação exposta no Santo Antônio', reportImageUrl: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400', type: 'existence', deadline: '2026-04-05T08:00:00', neighborhood: 'Santo Antônio', lat: -27.0110, lng: -51.1560 },
];

export const organLabels: Record<OrganType, string> = {
  prefeitura: 'Prefeitura Municipal',
  agua_saneamento: 'Água e Saneamento',
  energia_luz: 'Energia e Iluminação',
};

export const statusLabels: Record<ReportStatus, string> = {
  pre_publicacao: 'Pré-publicação (12h)',
  aguardando_validacao: 'Aguardando Validação',
  em_analise: 'Em Análise',
  em_execucao: 'Em Execução',
  resolvido: 'Resolvido pelo Órgão',
  resolucao_validada: 'Resolução Validada',
  resolucao_rejeitada: 'Resolução Rejeitada',
  arquivado: 'Arquivado',
};

export const getStatusColor = (status: ReportStatus): string => {
  const map: Record<ReportStatus, string> = {
    pre_publicacao: '#9CA3AF',
    aguardando_validacao: '#A855F7',
    em_analise: '#EAB308',
    em_execucao: '#0D9488',
    resolvido: '#22C55E',
    resolucao_validada: '#16A34A',
    resolucao_rejeitada: '#EF4444',
    arquivado: '#6B7280',
  };
  return map[status];
};

export const getCategoryById = (id: string) => categories.find(c => c.id === id);
export const getSubcategoryById = (categoryId: string, subcategoryId: string) =>
  getCategoryById(categoryId)?.subcategories.find(s => s.id === subcategoryId);

export const dashboardStats = {
  totalReports: 127,
  resolvedReports: 48,
  unresolvedReports: 79,
  avgResolutionDays: 12.3,
  activeReports: 79,
  avgFirstResponseDays: 3.2,
  resolutionRate: 37.8,
  avgUnresolvedDays: 18.5,
  recurrenceRate: 14.2,
  totalRecurrences: 18,
  reportsByNeighborhood: [
    { name: 'Centro', total: 28, resolved: 12, unresolved: 16, avgDays: 10.5, recurrences: 4 },
    { name: 'Alvorada', total: 18, resolved: 8, unresolved: 10, avgDays: 14.2, recurrences: 2 },
    { name: 'Farroupilha', total: 15, resolved: 7, unresolved: 8, avgDays: 11.8, recurrences: 3 },
    { name: 'Santo Antônio', total: 14, resolved: 4, unresolved: 10, avgDays: 19.3, recurrences: 1 },
    { name: 'São Cristóvão', total: 12, resolved: 6, unresolved: 6, avgDays: 8.7, recurrences: 2 },
    { name: 'Bom Retiro', total: 11, resolved: 5, unresolved: 6, avgDays: 15.1, recurrences: 2 },
    { name: 'Matriz', total: 9, resolved: 3, unresolved: 6, avgDays: 20.4, recurrences: 1 },
    { name: 'San Remo', total: 7, resolved: 1, unresolved: 6, avgDays: 22.1, recurrences: 2 },
    { name: 'Industrial', total: 6, resolved: 1, unresolved: 5, avgDays: 25.0, recurrences: 1 },
    { name: 'Panorama', total: 4, resolved: 1, unresolved: 3, avgDays: 30.2, recurrences: 0 },
    { name: 'Presidente Médici', total: 3, resolved: 0, unresolved: 3, avgDays: 35.0, recurrences: 0 },
  ],
  reportsByCategory: [
    { name: 'Infraestrutura', value: 42, recurrences: 8 },
    { name: 'Água/Saneamento', value: 28, recurrences: 5 },
    { name: 'Iluminação', value: 22, recurrences: 2 },
    { name: 'Energia', value: 18, recurrences: 3 },
    { name: 'Serviço Público', value: 10, recurrences: 0 },
    { name: 'Estrutural', value: 7, recurrences: 0 },
  ],
  reportsByOrgan: [
    { name: 'Prefeitura Municipal', total: 74, resolved: 30, avgDays: 11.2, recurrences: 10 },
    { name: 'Água e Saneamento', total: 28, resolved: 10, avgDays: 14.5, recurrences: 5 },
    { name: 'Energia e Iluminação', total: 25, resolved: 8, avgDays: 9.8, recurrences: 3 },
  ],
  reportsByMonth: [
    { month: 'Out', total: 8, resolved: 5, unresolved: 3 },
    { month: 'Nov', total: 12, resolved: 7, unresolved: 5 },
    { month: 'Dez', total: 15, resolved: 9, unresolved: 6 },
    { month: 'Jan', total: 20, resolved: 10, unresolved: 10 },
    { month: 'Fev', total: 28, resolved: 8, unresolved: 20 },
    { month: 'Mar', total: 44, resolved: 9, unresolved: 35 },
  ],
  reportsByStatus: [
    { name: 'Aguardando Validação', value: 12, color: '#A855F7' },
    { name: 'Em Análise', value: 38, color: '#EAB308' },
    { name: 'Em Execução', value: 35, color: '#0D9488' },
    { name: 'Resolvido (aguardando)', value: 8, color: '#22C55E' },
    { name: 'Validado', value: 28, color: '#16A34A' },
    { name: 'Rejeitado', value: 6, color: '#EF4444' },
  ],
  reportsByPriority: [
    { name: 'Crítica', value: 8, color: 'hsl(0, 84%, 60%)' },
    { name: 'Alta', value: 25, color: 'hsl(25, 95%, 53%)' },
    { name: 'Média', value: 52, color: 'hsl(45, 100%, 51%)' },
    { name: 'Baixa', value: 42, color: 'hsl(210, 14%, 70%)' },
  ],
  vandalism: {
    total: 19,
    avgFirstResponseDays: 2.4,
    avgResolutionDays: 8.7,
    pending: 11,
    recurrenceRate: 22.0,
    bySubcategory: [
      { name: 'Pichação', value: 9, recurrences: 3 },
      { name: 'Descarte Irregular de Lixo', value: 7, recurrences: 1 },
      { name: 'Destruição de Patrimônio Público', value: 3, recurrences: 0 },
    ],
    byNeighborhood: [
      { name: 'Centro', value: 6 },
      { name: 'Industrial', value: 4 },
      { name: 'Alvorada', value: 3 },
      { name: 'Matriz', value: 3 },
      { name: 'San Remo', value: 2 },
      { name: 'Farroupilha', value: 1 },
    ],
    byMonth: [
      { month: 'Out', total: 1 },
      { month: 'Nov', total: 2 },
      { month: 'Dez', total: 2 },
      { month: 'Jan', total: 3 },
      { month: 'Fev', total: 4 },
      { month: 'Mar', total: 7 },
    ],
  },
};
