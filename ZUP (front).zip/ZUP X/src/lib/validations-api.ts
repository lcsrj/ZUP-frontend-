// Validações comunitárias — convites pendentes do cidadão logado
// e ações de confirmar/rejeitar/não sei. Endpoints do back Node:
//   GET    /validation-invites           → lista do usuário logado
//   POST   /validations                  → { invite_id, decision: 'confirm'|'reject'|'unknown' }

import { api } from "@/lib/api";
import type { ValidationRequest } from "@/data/mockData";

export type ValidationDecision = "confirm" | "reject" | "unknown";

export interface BackendValidationInvite {
  id: number | string;
  occurrence_id: number | string;
  type: "existence" | "resolution";
  deadline?: string | null;
  neighborhood?: string | null;
  latitude?: number | string | null;
  longitude?: number | string | null;
  occurrence?: {
    title?: string;
    primary_image_url?: string | null;
    neighborhood?: string | null;
    latitude?: number | string | null;
    longitude?: number | string | null;
  } | null;
}

function toNum(v: unknown): number {
  const n = typeof v === "string" ? parseFloat(v) : (v as number);
  return Number.isFinite(n) ? n : 0;
}

export function mapInviteToRequest(i: BackendValidationInvite): ValidationRequest {
  return {
    id: String(i.id),
    reportId: String(i.occurrence_id),
    reportTitle: i.occurrence?.title ?? "Ocorrência",
    reportImageUrl: i.occurrence?.primary_image_url ?? "",
    type: i.type,
    deadline: i.deadline ?? new Date(Date.now() + 24 * 3600_000).toISOString(),
    neighborhood: i.neighborhood ?? i.occurrence?.neighborhood ?? "",
    lat: toNum(i.latitude ?? i.occurrence?.latitude),
    lng: toNum(i.longitude ?? i.occurrence?.longitude),
  };
}

export async function listMyInvites(): Promise<ValidationRequest[]> {
  const data = await api.get<BackendValidationInvite[] | { data: BackendValidationInvite[] }>(
    "/validation-invites"
  );
  const list = Array.isArray(data) ? data : data?.data ?? [];
  return list.map(mapInviteToRequest);
}

export async function submitValidation(inviteId: string | number, decision: ValidationDecision): Promise<void> {
  await api.post("/validations", { invite_id: inviteId, decision });
}
