// Contratos de ocorrências do backend Node (ProjetoZup-main).
// Inclui CRUD básico, upload de fotos (multipart) e mapeamento
// para o tipo Report usado hoje pelo front (sem quebrar o visual).

import { api } from "@/lib/api";
import type { Report, ReportStatus, Priority, OrganType } from "@/data/mockData";

export interface BackendPhoto {
  id: number;
  url: string;
  is_primary?: boolean;
}

export interface BackendOccurrence {
  id: number;
  protocol?: string;
  title: string;
  description: string;
  status: string;
  priority?: string | null;
  category_id?: string | null;
  subcategory_id?: string | null;
  category?: string | null;
  subcategory?: string | null;
  neighborhood?: string | null;
  neighborhood_id?: number | null;
  address_street?: string | null;
  address_number?: string | null;
  address_cep?: string | null;
  latitude?: number | string | null;
  longitude?: number | string | null;
  lat?: number | string | null;
  lng?: number | string | null;
  primary_image_url?: string | null;
  photos?: BackendPhoto[];
  organ?: string | null;
  validations_count?: number | null;
  reopens_count?: number | null;
  created_at?: string;
  updated_at?: string;
  published_at?: string | null;
  resolved_at?: string | null;
  user_id?: number | null;
  is_anonymous?: boolean | null;
}

const STATUS_MAP: Record<string, ReportStatus> = {
  pending: "aguardando_validacao",
  aguardando_validacao: "aguardando_validacao",
  in_analysis: "em_analise",
  em_analise: "em_analise",
  in_execution: "em_execucao",
  em_execucao: "em_execucao",
  resolved: "resolvido",
  resolvido: "resolvido",
  resolution_validated: "resolucao_validada",
  resolucao_validada: "resolucao_validada",
  resolution_rejected: "resolucao_rejeitada",
  resolucao_rejeitada: "resolucao_rejeitada",
};

const PRIORITY_MAP: Record<string, Priority> = {
  critical: "critica", critica: "critica",
  high: "alta", alta: "alta",
  medium: "media", media: "media",
  low: "baixa", baixa: "baixa",
};

function toNum(v: unknown): number {
  const n = typeof v === "string" ? parseFloat(v) : (v as number);
  return Number.isFinite(n) ? n : 0;
}

export function mapOccurrenceToReport(o: BackendOccurrence): Report {
  const lat = toNum(o.latitude ?? o.lat);
  const lng = toNum(o.longitude ?? o.lng);
  const photos = (o.photos ?? []).map(p => p.url).filter(Boolean);
  const primary = o.primary_image_url || photos[0] || "";
  const status = STATUS_MAP[o.status] ?? "aguardando_validacao";
  return {
    id: String(o.id),
    title: o.title,
    description: o.description,
    status,
    priority: PRIORITY_MAP[o.priority ?? ""] ?? "media",
    categoryId: o.category_id ?? o.category ?? "",
    subcategoryId: o.subcategory_id ?? o.subcategory ?? "",
    neighborhood: o.neighborhood ?? "",
    municipalityId: "videira-sc",
    lat,
    lng,
    imageUrl: primary,
    imageUrls: primary ? [primary, ...photos.filter(p => p !== primary)] : photos,
    createdAt: o.created_at ?? new Date().toISOString(),
    updatedAt: o.updated_at ?? o.created_at ?? new Date().toISOString(),
    validations: o.validations_count ?? 0,
    requiredValidations: 5,
    resolutionValidations: 0,
    organ: (o.organ as OrganType) ?? "prefeitura",
    statusHistory: [{ status, date: o.created_at ?? new Date().toISOString() }],
  };
}

export interface CreateOccurrencePayload {
  title: string;
  description: string;
  category_id: string;
  subcategory_id: string;
  neighborhood?: string | null;
  neighborhood_id?: number | null;
  latitude: number;
  longitude: number;
  address_street?: string;
  address_number?: string;
  address_cep?: string;
  is_anonymous?: boolean;
}

export async function createOccurrence(payload: CreateOccurrencePayload): Promise<BackendOccurrence> {
  return api.post<BackendOccurrence>("/occurrences", payload);
}

export async function uploadOccurrencePhotos(
  occurrenceId: number | string,
  files: File[]
): Promise<BackendPhoto[]> {
  if (!files.length) return [];
  const fd = new FormData();
  files.forEach((f, i) => {
    fd.append("photos", f, f.name || `photo-${i}.jpg`);
  });
  return api.post<BackendPhoto[]>(`/occurrences/${occurrenceId}/photos`, fd, { multipart: true });
}

export interface ListOccurrencesQuery {
  status?: string;
  category_id?: string;
  neighborhood?: string;
  priority?: string;
  q?: string;
  page?: number;
  per_page?: number;
}

export async function listOccurrences(q: ListOccurrencesQuery = {}): Promise<BackendOccurrence[]> {
  const data = await api.get<BackendOccurrence[] | { data: BackendOccurrence[] }>("/occurrences", {
    query: q as Record<string, any>,
    auth: false,
  });
  return Array.isArray(data) ? data : data?.data ?? [];
}

export async function getOccurrence(id: number | string): Promise<BackendOccurrence> {
  return api.get<BackendOccurrence>(`/occurrences/${id}`, { auth: false });
}

export async function updateOccurrence(id: number | string, patch: Partial<CreateOccurrencePayload>): Promise<BackendOccurrence> {
  return api.patch<BackendOccurrence>(`/occurrences/${id}`, patch);
}

export async function deleteOccurrence(id: number | string): Promise<void> {
  await api.delete(`/occurrences/${id}`);
}
