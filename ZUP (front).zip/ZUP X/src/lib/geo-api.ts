// Reverse geocode e autocomplete proxied pelo backend Node (/geo/*).
// Nunca chamamos Google Maps direto do front em produção.

import { api } from "@/lib/api";

export interface ReverseGeocodeResult {
  street: string;
  number: string;
  postalCode: string;
  neighborhood: string;
  formatted: string;
}

export async function reverseGeocode(lat: number, lng: number): Promise<ReverseGeocodeResult | null> {
  try {
    const data = await api.get<Partial<ReverseGeocodeResult>>("/geo/reverse", {
      query: { lat, lng },
      auth: false,
    });
    return {
      street: data?.street ?? "",
      number: data?.number ?? "",
      postalCode: data?.postalCode ?? "",
      neighborhood: data?.neighborhood ?? "",
      formatted: data?.formatted ?? "",
    };
  } catch (err) {
    console.warn("[geo] reverseGeocode falhou:", err);
    return null;
  }
}
